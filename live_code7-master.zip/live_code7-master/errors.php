<?php
echo "<p>We do not have this selection choice, please check again!</p>";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="https://web.njit.edu/~yz746/week7/index.php">Go Back to Home Page</a>
</body>
</html>