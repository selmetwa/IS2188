<?php
echo "<p>This is for showing how to add absolute directory.</p>";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="https://web.njit.edu/~yz746/week7/index.php">Go Back to Home Page</a>
</body>
</html>