<?php
session_start();
?>
<!DOCTYPE html>
<header>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Merienda+One|Rammetto+One|Sedgwick+Ave+Display" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Merienda+One|Press+Start+2P|Rammetto+One|Sedgwick+Ave+Display" rel="stylesheet">




</header>
<body>
  <?php
error_reporting(E_ALL); ini_set('display_errors', '1');
// define variables and set to empty values

//Validation of email
$emailErr = $UpasswordErr = "";
$email = "";
$Upassword = "";


class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  if (empty($_POST["email"])) {
    $emailErr = "*Email is required";
  } 
  else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
  }
  
    $Upassword = ($_POST["password"]);

  if (!empty($_POST["email"])) {
     $servername = "sql.njit.edu";
      $username = "sge5";
      $password = "eiB3WkRZ";
      $dbname = "sge5";


    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $stmt = $conn->prepare("SELECT email FROM accounts WHERE email = '$email'"); 
      $stmt->execute();

      // set the resulting array to associative
      $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 

      
      foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) { 
          
      }

      if ($v != '') {
        $conn = null;
         $servername = "sql.njit.edu";
        $username = "sge5";
        $password = "eiB3WkRZ";
       $dbname = "sge5";

        
        try {
          $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
          //echo "Connected Successfully! <br>";
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $conn->prepare("SELECT password FROM accounts WHERE password = '$Upassword'"); 
          $stmt->execute();

          // set the resulting array to associative
          $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 

          $v = '';
          foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) { 
            echo $v;
            echo $Upassword;
          }
            
          if ($v != '' && $Upassword != ''){
            $conn = null;
            $_SESSION["email"] = "$email";
            header( 'Location: finalpage.php' );
            $conn = null;
          }

          else{
            $UpasswordErr = "*Password is incorrect";
          }
        }
        catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
      }
      else {
        echo "<br>Email Incorrect";   
      }
      
      
    }   
    catch(PDOException $e) {
      echo "Error: " . $e->getMessage();
    }
    $conn = null;
  }
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  <div id="forms">
  <div class="form-group">
    <h1 id="title">Login Page</h1>
    <link href="https://fonts.googleapis.com/css?family=Merienda+One|Nosifer|Press+Start+2P|Rammetto+One|Sedgwick+Ave+Display" rel="stylesheet">

  </div>
   <div class="form-group">
    <label for="pwd"></label>
    <input type="email" class="form-control" id="pwd" placeholder="Enter Email" name="email">
  <div class="form-group">
    <label for="pwd"></label>
    <input type="password" class="form-control" id="pwd" placeholder="Password" name="password">
  </div>
 
  
  
  <button type="submit" id="button" onclick="window.location.href='finalpage.php'">Log In</button>
  </div>
</form>
</body>
</html>

<style>
#forms {
  margin-top: 3%;
  height: 320px;
  width: 700px;
  background-color: rgba(156, 162, 255, .2);
  border: 2px dashed #E55346;
  border-radius: 3%;
}
div {
    margin: auto;
    width: 50%;
    padding-top: 10px;
    
}
::placeholder {
  color: #E55346;
  font-family: Work Sans;
  padding-left: 10px;
  font-weight: bold;
  
}
input {
  background-color: rgba(255, 255, 255, .7);
  border: 1.5px dashed #E55346;
}
#1 {
  padding-top: 100px;
}
#fname {
  margin-top: 22px;
}
.form-group {
  padding-top: 35px;
  text-align: center;
  color: #E55346;
  font-family: Work Sans;
  font-size: 100%;
  letter-spacing: 2px;
  font-weight: bold;
}
#button {
  margin-left: 180px;
  margin-top: 30px;
  padding: 10px;
  width: 150px;
  height: 50px;
 font-family: 'Press Start 2P';  color: #E55346;
  border: 2px dashed #E55346;
  font-size: 110%;
  text-align: center;
  background-color: #ffffff;
  border-radius: 20px;
    }
#button:hover{
  color: white;
  background-color: #E55346;
  transition: 1s;
}

.form-control {
  height: 35px;
  width: 300px;
}
html {
  background-image: url("https://media.giphy.com/media/Fe22CajsYBJio/giphy.gif");
  background-size: 80;
}
#title{ 
  color: #E55346;
  font-family: 'Press Start 2P';
  margin-top: -10px;
  text-align: center;
  font-size: 160%;
  font-weight: bold;
}

  

  </style>