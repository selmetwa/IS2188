<!DOCTYPE html>
<header>
    <link href="https://fonts.googleapis.com/css?family=Merienda+One|Press+Start+2P|Rammetto+One|Sedgwick+Ave+Display" rel="stylesheet">
  <header>
<body>
  <div id="container">
  <h1 id="message">You have logged in successfully</h1>
    
  </div>
</body>
</html>

<style>
html {
  background: url("http://78.media.tumblr.com/24cf9574285e327aa77ee1972a127519/tumblr_mft4yuejdR1rby4vso1_500.gif");
  background-size: 61%;
}
h1 {
  font-family: 'Press Start 2P';
  margin-top: 21%;
  font-size: 200%;
  padding-top: 5%;
  color: white;
  text-align: center;
  font-weight: 600;
}
#container {
  height: 300px;
  width: 1200px;
  background-color: #6A0400;
  margin-left: 13%;
  opacity: .8;
}

	</style>